---
name: reply-to-text
description: Review text message conversations with a specified contact and send appropriate replies with cheerful tone and humor. This skill should be used when the user requests to reply to text messages, check conversations before responding, or wants to send contextual replies to contacts. Automatically handles contact lookup and conversation review via subagent delegation.
---

# Reply To Text

## Purpose

Review text message conversation history with a specified contact and send contextually appropriate replies with a cheerful tone and a bit of humor. This skill delegates to a subagent that uses the text-message skill to analyze the conversation and craft an engaging response.

## When to Use This Skill

Use this skill when:
- User requests to reply to a text message from a specific contact
- User wants to review a conversation before responding
- User asks to send a contextual reply to someone
- Keywords detected: "reply to text", "respond to [name]", "text back [name]", "answer [name]'s message"

**Trigger Patterns**:
- "Reply to [contact name]'s text"
- "Respond to [contact name]"
- "Text [contact name] back"
- "Answer [contact name]'s message"
- "Send a reply to [contact name]"

## Core Workflow

### 1. Contact Identification

**Contact Specified**:
```
User: "Reply to Michele Berry's text"

Parse contact name: "Michele Berry"
Proceed to subagent delegation
```

**No Contact Specified**:
```
User: "Reply to my latest text"

Prompt: "Which contact would you like to reply to?"
Wait for user response with contact name
Proceed to subagent delegation
```

### 2. Subagent Delegation

Use the Task tool to spawn a specialized subagent with the following configuration:

**Subagent Type**: `general-purpose`

**Subagent Prompt Template**:
```
Use the text-message skill to complete this task:

1. Review the recent conversation with [CONTACT_NAME]
2. Analyze the context and tone of their most recent message
3. Craft an appropriate reply that:
   - Responds to what they said
   - Maintains a cheerful, friendly tone
   - Includes a bit of humor when appropriate
   - Feels natural and conversational
4. Send the reply using the text-message skill

Important guidelines:
- Read enough of the conversation to understand the context
- Match the conversational style (casual vs formal)
- Avoid over-explaining or being too verbose
- Keep humor light and appropriate
- Ensure the reply feels authentic to Arlen's voice
```

**Delegation Pattern**:
```
Task(
  subagent_type="general-purpose",
  description="Review and reply to text",
  prompt="Use the text-message skill to review the conversation with [CONTACT_NAME] and send a cheerful, humorous reply that responds appropriately to their most recent message."
)
```

### 3. Result Confirmation

Once the subagent completes:
- Confirm that the reply was sent successfully
- Display what message was sent
- Note any relevant context from the conversation

## Workflow Examples

### Example 1: Named Contact
```
User: "Reply to Leah Burt's text"

Steps:
1. Parse contact name: "Leah Burt"
2. Spawn subagent with prompt:
   "Use the text-message skill to review the conversation with Leah Burt
   and send a cheerful, humorous reply that responds appropriately to
   their most recent message."
3. Subagent:
   - Uses text-message skill to read recent messages
   - Analyzes conversation context
   - Crafts appropriate reply
   - Sends message
4. Confirm completion: "✅ Reply sent to Leah Burt: [message preview]"
```

### Example 2: No Contact Specified
```
User: "Reply to that text message"

Steps:
1. Prompt: "Which contact would you like to reply to?"
2. User responds: "Michele Berry"
3. Spawn subagent with prompt:
   "Use the text-message skill to review the conversation with Michele Berry
   and send a cheerful, humorous reply that responds appropriately to
   their most recent message."
4. Subagent completes workflow
5. Confirm completion
```

### Example 3: Multiple Conversations
```
User: "Reply to both Leah and Michele"

Steps:
1. Parse contacts: ["Leah Burt", "Michele Berry"]
2. For each contact, spawn separate subagent:
   - Subagent 1: Handle Leah Burt's conversation
   - Subagent 2: Handle Michele Berry's conversation
3. Run subagents in parallel
4. Confirm completion for both:
   "✅ Replies sent:
   - Leah Burt: [preview]
   - Michele Berry: [preview]"
```

## Integration with Text-Message Skill

The subagent will automatically use the text-message skill to:

1. **Look up contact** via contacts skill if name provided
2. **Read conversation history** using `read_messages.sh`
3. **Analyze context** to understand the conversation flow
4. **Craft reply** that is contextually appropriate and cheerful
5. **Send message** using `send_message.sh`

The text-message skill handles all the technical details:
- Contact phone number resolution
- Message history retrieval
- Phone number formatting
- Message sending via Apple Messages

## Best Practices

### Tone Guidelines

**Cheerful**:
- Use positive language and enthusiasm
- Include friendly expressions
- Show genuine interest in the conversation

**Humorous**:
- Add light jokes or playful observations when appropriate
- Use self-deprecating humor occasionally
- Keep humor contextual and natural
- Avoid forced or excessive jokes

**Conversational**:
- Match the contact's communication style
- Use contractions and casual language (but remember apostrophes may cause send failures)
- Keep responses concise but warm
- Show personality

### Reply Crafting Strategy

1. **Acknowledge**: Respond directly to what they said
2. **Add Value**: Contribute something new to the conversation
3. **Engage**: Give them something to respond to if appropriate
4. **Keep It Light**: Maintain positive, friendly energy

### Subagent Guidance

Provide clear guidance to the subagent:
- Review enough message history to understand context (5-10 recent messages)
- Consider the relationship with the contact (friend, family, professional)
- Match their energy level and conversation style
- Avoid overthinking - natural replies are best
- If their message is a question, make sure to answer it

## Error Handling

**Contact Not Found**:
```
Subagent reports: "Contact [name] not found in contacts"

Response to user:
"❌ Could not find contact '[name]' in your contacts.
Please provide the correct name or phone number."

Wait for user clarification before retrying
```

**No Recent Messages**:
```
Subagent reports: "No recent messages from [contact]"

Response to user:
"ℹ️ No recent message history found with [contact].
Would you like to send a new message instead?"

Offer to use regular text-message skill instead
```

**Send Failure**:
```
Subagent reports: "Failed to send message to [contact]"

Response to user:
"❌ Failed to send reply to [contact]. Error: [details]
Would you like to try again or revise the message?"

Offer to retry or manually compose message
```

## Limitations

- **macOS Only**: Requires Apple Messages app
- **Contact Dependency**: Contact must exist in Google Contacts or phone number must be provided
- **Message History Access**: Requires Full Disk Access permissions for Terminal
- **Subagent Autonomy**: Replies are crafted by subagent based on guidelines; user can review afterwards
- **Humor Variance**: Quality and appropriateness of humor depends on subagent's interpretation

## Quick Reference

**Basic Usage**:
```
"Reply to [contact name]'s text"
```

**Subagent Delegation**:
```
Task(
  subagent_type="general-purpose",
  description="Review and reply to text",
  prompt="Use the text-message skill to review the conversation
          with [CONTACT_NAME] and send a cheerful, humorous reply."
)
```

**Confirmation Pattern**:
```
✅ Reply sent to [Contact Name]: "[message preview]"
```

---

**Version**: 1.0.0
**Dependencies**: text-message skill, contacts skill, Task tool with general-purpose subagent
